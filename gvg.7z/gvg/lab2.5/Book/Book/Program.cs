﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Book
{
    class Program
    {

        static void Main(string[] args)
        {

            string[,] s = new string[2, 4];
            for (int i = 0; i < s.GetLength(0); i++)
            {

                Console.WriteLine("Enter BookTitle:");
                s[i, 0] = Console.ReadLine();
                Console.WriteLine("Enter Book Author:");
                s[i, 1] = Console.ReadLine();
                Console.WriteLine("Enter Publisher:");
                s[i, 2] = Console.ReadLine();
                Console.WriteLine("Enter Price:");
                s[i, 3] = Console.ReadLine();


            }
            Console.WriteLine("Book Details are:");
            
            for (int i = 0; i < s.GetLength(0); i++)
            {

                
                Console.WriteLine($"Book Title is : { s[i, 0]}");
                Console.WriteLine($"Book Author is : {s[i, 1]}");
                Console.WriteLine($"Book Publisher is :{ s[i, 2]}");
                Console.WriteLine($"Book Priceis : { s[i, 3]}");



                Console.WriteLine();

              }
                Console.ReadKey();




        }


    }
}
