﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("*******copy file operation********");
                Console.WriteLine("enter source filename:");
                string sourceFileName = Console.ReadLine();
                string path = $@"C:\SURENDRA\LabBook\lab12.2\{sourceFileName}.txt";
                FileStream s = File.Create(path);
                string text = "this is 12.2 labbook ";
                s.Close();
                System.IO.File.WriteAllText($@"C:\SURENDRA\LabBook\lab12.2\{sourceFileName}.txt", text);


                Console.WriteLine("enter destination filename:");
                string destFileName = Console.ReadLine();
                string pat = $@"C:\SURENDRA\LabBook\lab12.2\{destFileName}.txt";
                File.Copy(path, pat);
                Console.WriteLine("copied successfully");


                Console.WriteLine("===============Reading the text from file===============================");
                string tex;
                var fileStream = new FileStream($@"C:\SURENDRA\LabBook\lab12.2\{sourceFileName}.txt", FileMode.Open, FileAccess.Read);
                using (var streamReader = new StreamReader(fileStream, Encoding.UTF8))
                {
                    tex = streamReader.ReadToEnd();
                }
                Console.WriteLine(tex);


            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("file not found");
            }
            Console.ReadLine();
        }
    }
}
