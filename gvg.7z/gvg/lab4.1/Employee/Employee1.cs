﻿//library**************************
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Employee
{
    public abstract class Employee1
    {

        protected int employeeId;
        protected string employeeName, address, city, department;
        protected double salary;

        abstract public void GetSalary();
    }

       public class ContractEmployee : Employee1
        {
            int perks = 1000;
            public int Perks
            {
                set { perks = value; }
                get { return perks; }

            }

            public void AcceptData()
            {
                Console.WriteLine("*******************************************");
                Console.WriteLine("Enter Details of Contract Employee");

                Console.WriteLine("Enter employee Id");
                employeeId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter employee name");
                employeeName = Console.ReadLine();

                Console.WriteLine("Enter employee Address");
                address = Console.ReadLine();

                Console.WriteLine("Enter employee city");
                city = Console.ReadLine();

                Console.WriteLine("Enter employee department");
                department = Console.ReadLine();

                Console.WriteLine("Enter employee salary");
                salary = Convert.ToDouble(Console.ReadLine());
                Perks = 1000;
            }

            public override void GetSalary()
            {
                salary = salary + Perks;
            }
            public void DisplayData()
            {
                Console.WriteLine("*******************************************");
                Console.WriteLine("Details of Contract Employee");
                Console.WriteLine("employee Id : " + employeeId);
                Console.WriteLine("mployee name : " + employeeName);
                Console.WriteLine("employee Address : " + address);
                Console.WriteLine("employee city : " + city);
                Console.WriteLine("employee department : " + department);
                Console.WriteLine("employee salary : " + salary);
                Console.WriteLine("*******************************************");
            }
        }


        public class PermanentEmployee : Employee1
        {
            int fund;
            public int ProvidentFund
            {
                set { fund = value; }
                get { return fund; }

            }

            int leaves;
            public int NoOfLeaves
            {
                set { leaves = value; }
                get { return leaves; }

            }
            public void AcceptData()
            {
                Console.WriteLine("*******************************************");
                Console.WriteLine("Enter Details of Permanent Employee");
                Console.WriteLine("Enter employee Id");
                employeeId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter employee name");
                employeeName = Console.ReadLine();

                Console.WriteLine("Enter employee Address");
                address = Console.ReadLine();

                Console.WriteLine("Enter employee city");
                city = Console.ReadLine();

                Console.WriteLine("Enter employee department");
                department = Console.ReadLine();

                Console.WriteLine("Enter employee salary");
                salary = Convert.ToDouble(Console.ReadLine());

                Console.WriteLine("Enter leaves");
                NoOfLeaves = Convert.ToInt32(Console.ReadLine());
                ProvidentFund = 1000;
            }

            public override void GetSalary()
            {
                salary = salary - ProvidentFund;
            }

            public void DisplayData()
            {

                Console.WriteLine("*******************************************");
                Console.WriteLine("Details of Permanent Employee");
                Console.WriteLine("employee Id : " + employeeId);
                Console.WriteLine("mployee name : " + employeeName);
                Console.WriteLine("employee Address : " + address);
                Console.WriteLine("employee city : " + city);
                Console.WriteLine("employee department : " + department);
                Console.WriteLine("employee salary : " + salary);
                Console.WriteLine("total leaves : " + NoOfLeaves);

                Console.WriteLine("*******************************************");
            }
        }




    }
//***********************


