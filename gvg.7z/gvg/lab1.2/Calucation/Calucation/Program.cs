﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ArthmeticLibrary;

namespace Calucation
{
    class Program
    {
        static void Main(string[] args)
        {
            ArthmeticOperations a = new ArthmeticOperations();
            Console.WriteLine("Enter two integer values  : ");
            int n1 = Convert.ToInt32( Console.ReadLine());
            int n2 = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter two double values : ");
            double n3 = Convert.ToDouble(Console.ReadLine());
            double n4 = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter  number '1' to perform Addition  ");
            Console.WriteLine("Enter  number '2' to perform Subtraction  ");
            Console.WriteLine("Enter  number '3' to perform Multiplication  ");
            Console.WriteLine("Enter  number '4' to perform Division  ");
            Console.WriteLine("Enter  number '5' to perform ModuloDivision  ");
            int k =Convert.ToInt32( Console.ReadLine());
            if(k==1)
            {

                a.Add(n1,n2);
                a.Add(n3,n4);
            }
            if(k == 2)
            {
                a.Sub(n1,n2);
                a.Sub(n3,n4);
            }
            if(k == 3)
            {
                a.Mul(n1,n2);
                a.Mul(n3,n4);
            }
            if(k==4)
            {
                a.Div(n1,n2);
                a.Div(n3,n4);
            }
            if(k==5)
            {
                a.Mod(n1,n2);
                a.Mod(n3,n4);
            }
           

        }
    }
}
