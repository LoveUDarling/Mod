﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class11._2
{
    public delegate void MakePaymentHandler(string message);
    public class CreditCard
    {
        public long CreditCardNo;
        public string CardHolderName;
        public double BalanceAmount;
        public double CreditLimit;
        public event MakePaymentHandler PaymentSuccessful = null;
        public CreditCard()
        {
            BalanceAmount = 0;
            CreditLimit = 50000;
        }
        public double GetBalance()
        {
            return BalanceAmount;
        }
        public double GetCreditLimit()
        {
            return CreditLimit;
        }
        public void MakePayment(double amount, string msg)
        {
            BalanceAmount += amount;

            if (PaymentSuccessful != null)
            {
                PaymentSuccessful(msg);
            }


        }

    }
}
