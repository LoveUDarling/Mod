﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Lab1;

namespace company
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Employee[] emp;
            Console.WriteLine("Enter number of Employees: ");
            int n = Convert.ToInt32(Console.ReadLine());
            emp = new Employee[n];
            for (int i = 0; i < n; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("enter employee ID");
                emp[i].ID = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("enter employee Name");
                emp[i].Name = Console.ReadLine();
                Console.WriteLine("enter employee Address");
                emp[i].Address = Console.ReadLine();
                Console.WriteLine("enter employee City");
                emp[i].city = Console.ReadLine();
                Console.WriteLine("enter employee Dipartment");
                emp[i].dipartment = Console.ReadLine();
                Console.WriteLine("enter employee Salary");
                emp[i].salary = Convert.ToDouble(Console.ReadLine());
            }
            for (int i = 0; i < n; i++)
            {
                Console.WriteLine($"Employee ID is: {emp[i].Name}");
                Console.WriteLine($"Employee Salary is:{emp[i].salary}");

            }
            Console.ReadLine();
        }
    }
}
