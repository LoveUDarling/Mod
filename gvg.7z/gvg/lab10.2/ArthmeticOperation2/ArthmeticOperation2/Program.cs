﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArthmeticOperation2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            Console.WriteLine("Enter 2 numbers:");
             a = Convert.ToInt32(Console.ReadLine());
            b = Convert.ToInt32(Console.ReadLine());
            MyDelegate del1 = new MyDelegate(ArithematicOperations.Add);
            ArithematicOperations. PerformArithmeticOperation(a, b, del1);
            del1 += new MyDelegate(ArithematicOperations.Sub);
            ArithematicOperations.PerformArithmeticOperation(a, b, del1);
            del1 += new MyDelegate(ArithematicOperations.Mul);
            ArithematicOperations.PerformArithmeticOperation(a, b, del1);
            del1 += new MyDelegate(ArithematicOperations.Div);
            ArithematicOperations.PerformArithmeticOperation(a, b, del1);
            Console.ReadKey();


        }
    }
}
