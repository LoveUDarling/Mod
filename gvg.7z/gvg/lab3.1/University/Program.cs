﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Participant;
namespace University
{
    class Program
    {
        static void Main(string[] args)


        {
            int empid;
            string name;
            int foundationmarks;
            int WebBasicMarks;
            int DotNetMarks;

            Participanty[] p;
            Console.WriteLine("Enter number of students you want to add");
            int size = int.Parse(Console.ReadLine());
            p = new Participanty[size];
            for (int i = 0; i < size; i++)
            {
                Console.WriteLine("Enter employee id:");
                empid = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter employee name:");
                name = Console.ReadLine();
                Console.WriteLine("Enter employee foundationmarks:");
                foundationmarks = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter employee webbasicmarks:");
                WebBasicMarks = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter employee DotnetMarks:");
                DotNetMarks = int.Parse(Console.ReadLine());
                p[i] = new Participanty(empid,name,foundationmarks,WebBasicMarks,DotNetMarks);
            }
           
            int g;
            do
            {
                Console.WriteLine("enter employee id you want to show:");
                int id = int.Parse(Console.ReadLine());
                Console.WriteLine("Enter a number:");
                Console.WriteLine("1.TotalMarks");
                Console.WriteLine("2.Percentage");
                Console.WriteLine("3.Exit");
                g = int.Parse(Console.ReadLine());
              

                if (g == 1)
                {
                   
                    for (int i = 0; i < size; i++)
                    {
                        if (p[i].EmpId == id)
                        {
                            Console.WriteLine($"Total marks of{p[i].EmpId} is:{ p[i].TotalM()}");
                        }

                    }
                }
                
                    if (g == 2)
                    {
                        for (int i = 0; i < size; i++)
                        {
                            if (p[i].EmpId == id)
                            {
                                Console.WriteLine($"percentage of{p[i].EmpId} is:{ p[i].DisplayPercentage()}");
                            }

                        }

                    }

                  

                
            } while (g != 3);

        }
    }
}
