﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SolidLab
{
    public interface IMessenger
    {
        void SendMessage();
    }
    public class Email : IMessenger
    {
        public void SendMessage()
        {
            Console.WriteLine("email message"); // code to send email
        }
    }

    public class SMS : IMessenger
    {
        public void SendMessage()
        {
            Console.WriteLine("sms message");
            // code to send SMS
        }
    }
    public class Notification
    {
        private IMessenger _iMessenger;
        private IMessenger _iMessenger1;
        public Notification()
        {
            _iMessenger = new Email();
            _iMessenger.SendMessage();

        }
        public void DoNotify()
        {
            _iMessenger1 = new SMS();
            _iMessenger1.SendMessage();
        }
        class Messenger
        {

        }
    }
}
