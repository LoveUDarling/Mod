﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using BAL;

namespace newProjectPL
{
    class Program
    {

        private static void PrintMenu()
        {
            string choice1;
            do
            {
                Console.WriteLine("\n***********Student Management System ***********");
                Console.WriteLine("1. Add student");
                Console.WriteLine("2. Delete student");
                Console.WriteLine("3. Get all student Details");
                Console.WriteLine("4. Search student");
                Console.WriteLine("5. Update student");
                Console.WriteLine("6.  Deserilized Data");
                Console.WriteLine("7. Serielization");
               

                int choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddStudent();
                        break;
                    case 2:
                        DeleteStudent();
                        break;
                    case 3:
                        ListAllStudents();
                        break;
                    case 4:
                        SearchStudent();
                        break;
                    case 5:
                        UpdateStudent();
                        break;
                    case 6:
                        Deserializable();
                        break;
                    case 7:
                        SerielizedData();
                        break;

                }
                Console.WriteLine("Do you want to contiue(y/n)?");
                choice1 = Console.ReadLine();
            } while ((choice1 == "y"));
            Console.Read();


        }


        //Add method.....
        /// <summary>
        /// 
        /// </summary>
        public static void Deserializable()
        {
            try

            {

                List<entityclass> Studentlist = bal.DeserializeData();

                if (Studentlist != null && Studentlist.Count > 0)

                {

                    Console.WriteLine("******************************************************************************");

                    Console.WriteLine("******************************************************************************");

                    foreach (entityclass student in Studentlist)

                    {

                        Console.WriteLine("{0}\t\t\t{1}\t\t{2}\t\t{3}\t\t{4}", student.studId, student.studName, student.studCourse,student.dateOfBirth, student.phoneNumber);

                    }

                    Console.WriteLine("******************************************************************************");

                }

                else

                {

                    Console.WriteLine("No Serialized Data Available");

                }

            }

            catch (studentNOTfoundException ex)

            {

                Console.WriteLine(ex.Message);

            }

        }
        public static void SerielizedData()
        {
            try

            {

                //entityclass newstudent = new entityclass();
                //Console.WriteLine("Enter Salesman Name :");
                //newstudent.studName = Console.ReadLine();

                //Console.WriteLine("Enter student course :");
                //newstudent.studCourse = Console.ReadLine();

                //Console.WriteLine("Enter student phone number :");
                //newstudent.phoneNumber = Console.ReadLine();

                //Console.WriteLine("Enter student date of birth :");
                //newstudent.dateOfBirth = Convert.ToDateTime(Console.ReadLine());

               

                bool studentSerialized = bal.SerializeData();

                if (studentSerialized)

                    Console.WriteLine("student Serialized");

                else

                    Console.WriteLine("student not Serialized");
               

            }

            catch (studentNOTfoundException ex)

            {

                Console.WriteLine(ex.Message);

            }
            
         

        }
    





        public static void AddStudent()
        {
            try
            {
                entityclass student = new entityclass();
                Console.WriteLine("Enter Student Id :");
                student.studId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter student Name :");
                student.studName = Console.ReadLine();
                Console.WriteLine("Enter student Qualification :");
                student.studCourse = Console.ReadLine();
                Console.WriteLine("Enter student Mobile Number :");
                student.phoneNumber = Console.ReadLine();
               
                Console.WriteLine("Enter student DOB :");
                student.dateOfBirth = Convert.ToDateTime(Console.ReadLine());

                bool StudentAdded = bal.AddApplicantBAL(student);
                if (StudentAdded == true)
                {
                    Console.WriteLine("Student Added Successfully");
                }
                else
                {
                    throw new studentNOTfoundException("Student not added");
                }

            
            
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


        //Search method....
        /// <summary>
        /// 
        /// </summary>

        public static void SearchStudent()
        {
            int studId;
            entityclass searchStudent;
            try
            {
                Console.WriteLine("Enter studentId to Search:");
                studId =Convert.ToInt32( Console.ReadLine());
                searchStudent = bal.SearchstudentBAL(studId);

                if (searchStudent != null)
                {
                    Console.WriteLine("student Name:" + searchStudent.studName);
                    Console.WriteLine("student Qualification" + searchStudent.studCourse);
                    Console.WriteLine("student mobile number" + searchStudent.phoneNumber);
                
                    Console.WriteLine("student Date Of Birth " + searchStudent.dateOfBirth);
                }
                else
                {
                    throw new studentNOTfoundException("Student not Found");
                }
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Display method.......
        /// <summary>
        /// 
        /// </summary>

        private static void ListAllStudents()
        {
            try
            {
                List<entityclass> studentList = bal.GetAll_bal();
                if (studentList != null && studentList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("StudentId\t\tStudentName\t\tPhoneNumber\t\tDateOfBirth\t\tStudentCourse");
                    Console.WriteLine("******************************************************************************");
                    foreach (entityclass student in studentList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}\t\t{3}\t\t{4}", student.studId, student.studName, student.phoneNumber, student.dateOfBirth, student.studCourse);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No student Details Available");
                }
            }
            catch (studentNOTfoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        // update method.....
        /// <summary>
        /// 
        /// </summary>

        private static void UpdateStudent()
        {
            try
            {
                int updateStudentId;
                Console.WriteLine("Enter studentId to Update Details:");
                updateStudentId = Convert.ToInt32( Console.ReadLine());

                entityclass UpdateStudent = bal.SearchstudentBAL(updateStudentId);

                if (UpdateStudent != null)
                {
                    Console.WriteLine("Update student Name :");
                    UpdateStudent.studName = Console.ReadLine();
                    Console.WriteLine("Update student PhoneNumber :");
                    UpdateStudent.phoneNumber = Console.ReadLine();
                    Console.WriteLine("update Student Course :");
                    UpdateStudent.studCourse = Console.ReadLine();
                    Console.WriteLine("update date of birth :");
                    UpdateStudent.dateOfBirth = Convert.ToDateTime(Console.ReadLine());

                    bool studentUpdated = bal.UpdatestudentBL(UpdateStudent);

                    if (studentUpdated)

                        Console.WriteLine("student Details Updated");

                    else

                        Console.WriteLine("student Details not Updated ");
                }
                else
                {
                    Console.WriteLine("No student Details Available");
                }
            }
            catch (studentNOTfoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        /// <summary>
        /// delete student
        /// </summary>

        private static void DeleteStudent()
        {
            try
            {
                int deletestudentID;
                Console.WriteLine("Enter studentId to Delete:");
                deletestudentID = Convert.ToInt32(Console.ReadLine());
                bool patientdeleted = bal.DeletestudentBL(deletestudentID);
                if (patientdeleted)
                    Console.WriteLine("student Deleted");
                else
                    Console.WriteLine("student not Deleted ");


            }
            catch (studentNOTfoundException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        


        static void Main(string[] args)
        {
            PrintMenu();
        }
    }
}
