﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exception;
using DAL;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text.RegularExpressions;

namespace BAL
{

    public class bal
    {
        public static List<entityclass> std = new List<entityclass>();
        public static object studs;

        private static bool ValidateStudent(entityclass student)
        {
            StringBuilder sb = new StringBuilder();
            bool validstudent = true;

            // checking whether qualification entered is BE, ME, MCA

            if ((student.studCourse != "BE") && (student.studCourse != "ME") && (student.studCourse != "MCA"))
            {
                validstudent = false;
                sb.Append(Environment.NewLine + "Qualification has to be BE, ME , MCA and should be in same format as capitals");

            }
            //if (!(Regex.IsMatch(student.studId.ToString(), @"^[0-9]{4}-[0-9]{4}-[0-9]{4}$")))
            //{
            //    validstudent = false;
            //    sb.Append(Environment.NewLine + "studentId or SerialNUmber must contain digits only and between 4 digits u must enter slash");
            //}

            //if (!(Regex.IsMatch(student.studName, "[A-Z][a-z]{3,}")))
            //{
            //    validstudent = false;
            //    sb.Append("student Name must have only characters starting with uppercase " + Environment.NewLine);
            //}



            // checking whether the entered student id is 6 digits or not

            //if (student.studId.Length != 6)
            //{
            //    validstudent = false;
            //    sb.Append(Environment.NewLine + "Required 6 digit student Id");
            //}



            //if (!(Regex.IsMatch(student.phoneNumber.ToString(), "^[6-9][0-9]{9}$")))
            //{
            //    validstudent = false;
            //    sb.Append("Patient contact should have 10 digits or First digit should be greater than 6" + Environment.NewLine);
            //}



            // Checking whether the entered phone number is 10 digits or not

            if (student.phoneNumber.Length != 10)
            {
                validstudent = false;
                sb.Append(Environment.NewLine + "Required 10 Digit Contact Number");
            }

            if (validstudent == false)
                throw new studentNOTfoundException(sb.ToString());
            return validstudent;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="newstudent"></param>
        /// <returns></returns>

        public static bool AddApplicantBAL(entityclass newstudent)
        {
            bool studentAdded = false;
            try
            {
                if (ValidateStudent(newstudent))
                {
                    dal studentDal = new dal();
                    studentAdded = studentDal.Add_dal(newstudent);
                }
            }
            catch (studentNOTfoundException)
            {
                throw;
            }
            catch (System.Exception ex)
            {
                throw ex;
            }

            return studentAdded;
        }

        /// <summary>
        /// 
        /// </summary>
        public static bool SerializeData()
        {
          return  dal.SerializeData();
        }

        /// <summary>
        /// /
        /// </summary>
        public static List<entityclass> DeserializeData()
        {
            
            return dal.DeserializeData();
        }

        // Searching the data from applicants on the basis of Qualification
        /// <summary>
        /// 
        /// </summary>
        /// <param name="searchStudId"></param>
        /// <returns></returns>

        public static entityclass SearchstudentBAL(int searchStudId)
        {
            entityclass searchStudent = null;
            try
            {
                dal studentDAL = new dal();
                searchStudent = studentDAL.searchstud_dal(searchStudId);
            }
            catch (studentNOTfoundException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return searchStudent;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>

        public static List<entityclass> GetAll_bal()
        {
            List<entityclass> studentList = null;
            try
            {
                dal studentDAL = new dal();
                studentList = studentDAL.GetAll_dal();
            }
            catch (studentNOTfoundException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return studentList;
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="deletestudId"></param>
        /// <returns></returns>

        public static bool DeletestudentBL(int deletestudId)
        {
            bool studentDeleted = false;
            try
            {


                if (deletestudId >0)
                {
                    dal studentDAL = new dal();
                    studentDeleted = studentDAL.Deletestud_dal(deletestudId);
                }
                else
                {
                    throw new studentNOTfoundException("Invalid student ID");
                }
            }
            catch (studentNOTfoundException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studentDeleted;
        }


        /// <summary>
        /// 
        /// </summary>
        /// <param name="updatestudent"></param>
        /// <returns></returns>
        /// 
        public static bool UpdatestudentBL(entityclass updatestudent)
        {
            bool studentUpdated = false;
            try
            {
                if (ValidateStudent(updatestudent))
                {
                    dal patientDAL = new dal();
                    studentUpdated = patientDAL.Updatestud_dal(updatestudent);
                }
            }
            catch (studentNOTfoundException)
            {
                throw;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return studentUpdated;
        }

    }
}
