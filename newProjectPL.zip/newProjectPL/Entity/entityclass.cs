﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    [Serializable]
    public class entityclass
    {
        public int studId { get; set; }
        public string studName { get; set; }
        public string studCourse { get; set; }
        public string phoneNumber { get; set; }
        public DateTime dateOfBirth { get; set; }
    }
}
