﻿namespace Mathop
{
    internal class espace
    {
    }
}