﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Mathop
{
    class Program
    {
        readonly espace AbstractMethods1;

    abstract class Mathop
        {
            abstract public int AddNumbers();
            abstract public int SubNumbers();

        }
        class MathClass : Mathop
        {
            int n1, n2, temp1, tenp2;
            public override int AddNumbers()
            {
                temp1 = n1 + n2;
                return temp1;
            }

            public override int SubNumbers()
            {
                int temp2 = n1 - n2;
                return temp2;
            }
        }
        public class Type_IsAbstract
        {
            public static void Main()
            {
                Console.WriteLine((typeof(Mathop).IsAbstract));
                Console.WriteLine((typeof(MathClass).IsAbstract));
                Console.ReadKey();
            }
        }
    }
    
}
