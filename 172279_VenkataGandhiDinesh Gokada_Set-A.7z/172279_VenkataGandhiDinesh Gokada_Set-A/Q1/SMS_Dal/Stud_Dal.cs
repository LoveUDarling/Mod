﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;
using Stud_Exception;


namespace SMS_Dal
{
    public class Stud_Dal
    {
        public static List<Studs> student = new List<Studs>();

        public bool AddStudentDAL(Studs student)
        {
            bool studentAdded = false;
            try
            {
                Studs.Add(student);
                studentAdded = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return studentAdded;

        }
        // Display the student
        public List<Studs> SelectAll()
        {
            return student;
        }





        public static void SerializeData()
        {
            FileStream stream;
            try
            {
                stream = new FileStream(@"Student.txt", FileMode.Create, FileAccess.Write);
                BinaryFormatter formatter = new BinaryFormatter();
                formatter.Serialize(stream, student);
                stream.Close();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static List<Studs> DeserializeData()
        {
            FileStream stream = new FileStream(@"Student.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter formatter = new BinaryFormatter();
            student = formatter.Deserialize(stream) as List<Studs>;
            return student;
        }

       



    }
}
