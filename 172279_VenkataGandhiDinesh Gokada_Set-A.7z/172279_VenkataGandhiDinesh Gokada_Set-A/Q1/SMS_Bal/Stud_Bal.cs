﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;
using Stud_Exception;
using SMS_Dal;

 

namespace SMS_Bal
    {
        public class Stud_Bal
        {


            private static bool ValidateStudent(Studs student)
            {
                StringBuilder sb = new StringBuilder();
                bool validStudent = true;
                if (student.StudentId <= 0)
                {
                    validStudent = false;
                    sb.Append(Environment.NewLine + "Invalid student ID");

                }
                if (student.StudentName == string.Empty)
                {
                    validStudent = false;
                    sb.Append(Environment.NewLine + "student Name Required");

                }

            }

            public static bool AddStudentBAL(Studs newStudent)
            {
                bool studentAdded = false;
                try
                {
                    if (ValidateStudent(newStudent))
                    {
                        Stud_Dal studentDAL = new Stud_Dal();
                        studentAdded = studentDAL.AddStudentDAL(newStudent);
                    }
                }
                catch (StudentNotFoundException)
                {
                    throw;
                }
                catch (Exception ex)
                {
                    throw ex;
                }

                return studentAdded;
            }
            public static void SerializeData()
            {
                Stud_Dal.SerializeData();
            }
            public static void DeserializeData()
            {
                Stud_Dal.DeserializeData();
            }
            static Stud_Dal dal = new Stud_Dal();

            // Adding the Student 
            public void Add(Studs student)
            {
                dal.AddStudentDAL(student);
            }

            // Display the student
            public List<Studs> GetALL()
            {
                return dal.SelectAll();
            }

        }
    }



