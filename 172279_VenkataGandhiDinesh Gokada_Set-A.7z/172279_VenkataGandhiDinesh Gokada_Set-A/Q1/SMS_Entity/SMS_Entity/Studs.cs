﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SMS_Entity
{

    /// <summary>
    /// serializable class
    /// </summary>
    /// 

    [Serializable]
    public class Studs
    {
        static int count;

        public Studs()
        {
            count++;
            StudentId = count;
        }

        public static void Add(Studs student)
        {
            throw new NotImplementedException();
        }

        //Student name should accept only Alphabets
        public int StudentId { get; set; }
        //StudentId should have 6 Digits
        public string StudentName { get; set; }
        //Student Course
        public string Course { get; set; }
        //Student Grade can be A, B, C, or F
        public char Grade { get; set; }


    }
}
