﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SMS_Entity;
using Stud_Exception;

namespace StudentManagementSystem_PL
{
    class Program
    {
        private static object pubstatic;

        public static object StudentBAL { get; private set; }

        public static void AddStudent()
        {
            try
            {
                Studs student = new Studs();
                Console.WriteLine("Enter Student RollNo:");
                student.StudentId = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter Student Name:");
                student.StudentName = Console.ReadLine();
                Console.WriteLine("Enter Student Course :");
                student.Course = Console.ReadLine();
                Console.WriteLine("Enter Studen Grade :");
                student.Grade = Convert.ToChar(Console.ReadLine());


                bool StudentAdded = StudentBAL.AddStudentBAL(student);
                if (StudentAdded == true)
                {
                    Console.WriteLine("Student Added Successfully");
                }
                else
                {
                    throw new StudentNotFoundException("Student not added");
                }
                StudentBAL.SerializeData();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        public static void DeleteStudent()
        {
            int RollNo;
            bool StudentDeleted;
            try
            {
                Console.WriteLine("Enter Student RollNo to be deleted:");
                RollNo = Convert.ToInt32(Console.ReadLine());




                 static void PrintMenu()
                {

                    Console.WriteLine();
                    Console.WriteLine("**********Student Menu**********");
                    Console.WriteLine("1.Add Student\n");
                    Console.WriteLine("2.Display\n");


                }
                static void Main(string[] args)
                {


                    int choice;
                    do
                    {
                        PrintMenu();
                        bool validChoice;
                        Console.WriteLine("Enter your Choice Please:");
                        validChoice = Int32.TryParse(Console.ReadLine(), out choice);

                        if (!validChoice)
                            Console.WriteLine("Enter the choice from 1-4");
                        else
                        {
                            switch (choice)
                            {
                                case 1:
                                    AddStudent();
                                    break;
                                case 2:
                                    Display();
                                    break;


                                default:
                                    Console.WriteLine("Invalid Choice");
                                    break;
                            }
                        }


                    } while (choice != 0);
                    Console.ReadKey();
                }





                public static void Display()
                {
                    throw new NotImplementedException();
                }

           



}
    }

